import java.util.Scanner;
public class task14
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner (System.in);
        System.out.println("Please enter the row number.");
        int rowInput = keyboard.nextInt();
        System.out.println("Please enter the column number.");
        int col = keyboard.nextInt();
        for(int row = 1; row <= rowInput; row++) {
            if(row == 1 || row == rowInput) {
                for(int i = 1; i <= col; i++) {
                    System.out.print("*");
                }
                System.out.println();
            }
            else {
                for(int i = 1; i <= col; i++) {
                    if(i == 1 || i == col) {
                        System.out.print("*");
                    }
                    else {
                        System.out.print(" ");
                    }
                }
                System.out.println();
            }
        }
    }
}