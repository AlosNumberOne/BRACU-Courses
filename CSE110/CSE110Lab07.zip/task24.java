import java.util.Scanner;
public class task24
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner (System.in);
        System.out.println("Please enter the limit.");
        int limit = keyboard.nextInt();
        for(int i = 1; i <= limit; ++i) {
            System.out.print(i);
        }
        for(int j = (limit - 1); j >= 1; --j) {
            System.out.print(j);
        }
    }
}