import java.util.Scanner;
public class task3
{
    public static void main(String [] args)
    {
        Scanner keyboard = new Scanner (System.in);
        System.out.println("Please enter the row number.");
        int row = keyboard.nextInt();
        System.out.println("Please enter the column number.");
        int col  = keyboard.nextInt();
        for(int i = 1; i <= row; i++) {
            for(int k = 1; k <= col; k++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}