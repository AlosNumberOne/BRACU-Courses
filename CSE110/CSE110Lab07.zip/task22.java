import java.util.Scanner;
public class task22
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner (System.in);
        System.out.println("Please enter the height.");
        int height = keyboard.nextInt();
        for(int row = 1; row <= (2 * height - 1); row++) {
            if(row <= height) {
                for(int i = 1; i <= (height - row); i++) {
                    System.out.print(" ");
                }
                for(int j = 1; j <= (2 * row - 1); j++) {
                    if(j == 1 || j == (2 * row - 1)) {
                        System.out.print("*");
                    }
                    else {
                        System.out.print(" ");
                    }
                }
                System.out.println();
            }
            else {
                for(int i = 1; i <= (row - height); i++) {
                    System.out.print(" ");
                }
                for(int j = 1; j <= (2 * height - 1) - 2 * (row - height); j++) {
                    if(j == 1 || j == (2 * height - 1) - 2 * (row - height)) {
                        System.out.print("*");
                    }
                    else {
                        System.out.print(" ");
                    }
                }
                System.out.println();
            }
        }
    }
}