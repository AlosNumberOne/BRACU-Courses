import java.util.Scanner;
public class task18
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner (System.in);
        System.out.println("Please enter the height.");
        int height = keyboard.nextInt();
        for(int row = 1; row <= height; row++) {
            if(row == 1) {
                for(int i = 1; i < height; i++) {
                    System.out.print(" ");
                }
                System.out.println("*");
            }
            else if(row == height) {
                for(int i = 1; i <= height; i++) {
                    System.out.print("*");
                }
            }
            else {
                for(int j = 1; j <= height; j++) {
                    if(j == (height - row + 1) || j == height) {
                        System.out.print("*");
                    }
                    else {
                        System.out.print(" ");
                    }
                }
                System.out.println();
            }
        }
    }
}