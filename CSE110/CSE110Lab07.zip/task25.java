import java.util.Scanner;
public class task25
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner (System.in);
        System.out.println("Please enter the height.");
        int height = keyboard.nextInt();
        for(int row = 1; row <= height; row++) {
            for(int i =  1; i <= (height - row); i++) {
                System.out.print(" ");
            }
            for(int j = 1; j <= row; j++) {
                System.out.print(j);
            }
            for(int k = (row - 1); k >= 1;  k--) {
                System.out.print(k);
            }
            System.out.println();
        }
    }
}