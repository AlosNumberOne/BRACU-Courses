import java.util.Scanner;
public class task19
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner (System.in);
        System.out.println("Please enter the height.");
        int height = keyboard.nextInt();
        for(int row = 1; row <= height; row++) {
            if(row == 1) {
                for(int i = 1; i < height; i++) {
                    System.out.print(" ");
                }
                System.out.println(height);
            }
            else if(row == height) {
                for(int i = 1; i <= height; i++) {
                    System.out.print(i);
                }
            }
            else {
                for(int i = 1; i <= height; i++) {
                    if(i == (height - row + 1) || i == height) {
                        System.out.print(i);
                    }
                    else {
                        System.out.print(" ");
                    }
                }
                System.out.println();
            }
        }
    }
}