import java.util.Scanner;
public class task4
{
    public static void main(String [] args)
    {
        Scanner keyboard = new Scanner (System.in);
        System.out.println("Please enter the row number.");
        int row = keyboard.nextInt();
        System.out.println("Please enter ther column number.");
        int col = keyboard.nextInt();
        for(int i = 1; i <= row; i++) {
            for(int k = 1; k <= col ; k++) {
                System.out.print(k);
            }
            System.out.println();
        }
    }
}