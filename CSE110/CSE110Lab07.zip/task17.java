import java.util.Scanner;
public class task17
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner (System.in);
        System.out.println("Please enter the height.");
        int height = keyboard.nextInt();
        for(int row = 1; row <= height; row++) {
            if(row == 1 || row == 2 || row == height) {
                for(int i = 1; i <= row; i++) {
                    System.out.print(i);
                }
                System.out.println();
            }
            else {
                for(int i = 1; i <= row; i++) {
                    if(i == 1 || i == row) {
                        System.out.print(i);
                    }
                    else {
                        System.out.print(" ");
                    }
                }
                System.out.println();
            }
        }
    }
}