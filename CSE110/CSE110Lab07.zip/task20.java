import java.util.Scanner;
public class task20
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner (System.in);
        System.out.println("Please enter the height.");
        int height = keyboard.nextInt();
        for(int row = 1; row <= height; row++) {
            if(row == 1) {
                for(int i = 1; i < height; i++) {
                    System.out.print(" ");
                }
                System.out.println("*");
            }
            else if(row == height) {
                for(int i = 1; i <= (2 * height - 1); i++) {
                    System.out.print("*");
                }
            }
            else {
                for(int i = 1; i <= (height - row); i++) {
                    System.out.print(" ");
                }
                for(int j = 1; j <= (2 * row - 1); j++) {
                    if(j == 1 || j == (2 * row - 1)) {
                        System.out.print("*");
                    }
                    else {
                        System.out.print(" ");
                    }
                }
                System.out.println();
            }
        }
    }
}