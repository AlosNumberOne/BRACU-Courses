import java.util.Scanner;
public class task1
{
    public static void main(String [] args)
    {
        Scanner keyboard = new Scanner (System.in);
        System.out.println("Please enter limit.");
        int limit = keyboard.nextInt();
        for(int i = 1; i <= limit; i++) {
            System.out.print(i);
        }
    }
}