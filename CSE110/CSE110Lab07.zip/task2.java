import java.util.Scanner;
public class task2
{
    public static void main(String [] args)
    {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Please enter the limit.");
        int limit = keyboard.nextInt();
        for(int i = 1; i <= limit; i++) {
            System.out.print("*");
        }
    }
}