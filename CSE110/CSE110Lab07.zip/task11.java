import java.util.Scanner;
public class task11
{
    public static void main(String [] args)
    {
        Scanner keyboard = new Scanner (System.in);
        System.out.println("Please enter the height.");
        int height = keyboard.nextInt();
        for(int i = 1; i <= height; i++) {
            for(int j = 1; j <= (height - i); j++) {
                System.out.print(" ");
            }
            for(int k = (height - i + 1); k <= height; k++) {
                System.out.print(k);
            }
            System.out.println();
        }
    }
}