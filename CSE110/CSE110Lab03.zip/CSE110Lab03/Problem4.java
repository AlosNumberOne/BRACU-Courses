import java.util.Scanner;
public class Problem4{
  public static void main(String[] args){
    Scanner sc=new Scanner(System.in);
    System.out.println("Please enter the radious of circle:");
    double radious=sc.nextDouble();
    double area;
    area=3.1416*radious*radious;
    System.out.println("The area is:"+ area);
    double circumference;
    circumference=2*3.1416*radious;
    System.out.println("The circumference is:"+circumference);
    
  }
}