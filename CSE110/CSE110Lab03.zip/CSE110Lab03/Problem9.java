import java.util.Scanner;
public class Problem9
{
  public static void main(String [] args)
  {
    Scanner sc=new Scanner(System.in);
    System.out.println("Please enter the number:");
    int a=sc.nextInt();
    if(a%2==0)
    {
      System.out.println("The number is even");
    }
    else
    {
      System.out.println("The number is odd");
    }
  }
}