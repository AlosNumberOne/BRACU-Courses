import java.util.Scanner;
public class Problem6
{
  public static void main(String[] args)
  {
    Scanner sc=new Scanner(System.in);
    System.out.println("Please enter the first number:");
    int a=sc.nextInt();
    System.out.println("Please enter the second number:");
    int b=sc.nextInt();
    if(a>b)
    {
      System.out.println("first is greater");
    }
    else
    {
      System.out.println("first is not greater");
    }
  }
}