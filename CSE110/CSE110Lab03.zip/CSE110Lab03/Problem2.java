import java.util.Scanner;
public class Problem2
{
  public static void main(String [] args)
  {
    Scanner sc=new Scanner(System.in);
    System.out.println("Please enter fisrt number:");
    int a=sc.nextInt();
    System.out.println("Please enter Second number:");
    int b=sc.nextInt();
    int sum;
    sum=a+b;
    System.out.println("The sum is:"+sum);
    int product;
    product=a*b;
    System.out.println("The product is:"+product);
    int difference;
    difference=a-b;
    System.out.println("The difference is:"+difference);
    
  }
}