import java.util.Scanner;
public class Problem3
{
  public static void main(String [] args)
  {
    Scanner sc=new Scanner(System.in);
    System.out.println("Please enter fisrt number:");
    float a=sc.nextFloat();
    System.out.println("Please enter Second number:");
    float b=sc.nextFloat();
    float sum;
    sum=a+b;
    System.out.println("The sum is:"+sum);
    float product;
    product=a*b;
    System.out.println("The product is:"+product);
    float difference;
    difference=a-b;
    System.out.println("The difference is:"+difference);
    
  }
}