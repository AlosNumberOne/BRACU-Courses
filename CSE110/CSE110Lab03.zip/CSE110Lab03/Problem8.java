import java.util.Scanner;
public class Problem8
{
  public static void main(String [] args)
  {
    Scanner sc=new Scanner(System.in);
    System.out.println("Please enter the first number:");
    int a=sc.nextInt();
    System.out.println("Please enter second number:");
    int b=sc.nextInt();
    if(a>b)
    {
      System.out.println(a);
      int subtract;
      subtract=a-b;
      System.out.println(subtract);
    }
    else
    {
      System.out.println(b);
      int subtract;
      subtract=b-a;
      System.out.println(subtract);
    }
  }
}